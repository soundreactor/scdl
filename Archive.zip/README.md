# scdl

warning! the code is a mess!  

im not really interested in fixing bugs or adding features. thats why i created the repo.

uses  
https://github.com/egoroof/browser-id3-writer  
https://github.com/eligrey/FileSaver.js/  

