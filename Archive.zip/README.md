# scdl

works in chrome & firefox

warning! the code is a mess!  

i will try my best to keep this working.

im not really interested in fixing bugs or adding features. thats why i created the repo.

uses  
https://github.com/egoroof/browser-id3-writer  
https://github.com/eligrey/FileSaver.js/  

for chrome:      
download to a folder and     
chrome://extensions/ .     
enable developer (mode top right) .      
load unpacked .      
